# 어떤 입력을 받아서 어떤 리턴을 줄 것인가.
# 입력 방법 => (1) 주소값 (2) Form

from flask import Flask, render_template


app = Flask(__name__)

# 플라스크는 주소 요청을 받아들여서 필요한 내용을 리턴해준다.
# 내 주소에 아무것도 입력하지 않은 것이 '/'이다.
@app.route('/') # route는 경로에 따라 보여줄 것들을 설정할 수 있다.
def index():
    # TODO 나 열심히 할게요
    return render_template('index.html')


@app.route('/a') # route는 경로에 따라 보여줄 것들을 설정할 수 있다.
def hello_simon():
    # TODO 나 열심히 할게요
    return '<h1>Hello Simon!!</h1>'


@app.route('/study<number>') # route는 경로에 따라 보여줄 것들을 설정할 수 있다.
def study_auto(number):
    return render_template("study{}.html".format(number))

@app.route('/extended') # route는 경로에 따라 보여줄 것들을 설정할 수 있다.
def extend_test():
    return render_template("extended.html")


@app.route('/dynamic/<name>') # Dynamic하게 구동하고 싶을 때는 <>로 변수를 만들어준다.
def dynamic_test(name):
    # TODO 나 열심히 할게요
    return '<h1>%s!!!</h1>' %name


@app.route('/ch11')
def ch11():
    return render_template('ch11_스크래핑, 크롤링.html')

@app.route('/<path>')
@app.route('/chapter/<path>')
def chapter(path = None):
    if path =='a' :
        return render_template('ch01_python.html')
    elif path == 'b' :
        return render_template('ch02_python.html')
    elif path == 'c' :
        return render_template('ch03_homework.html')
    if path :
        return render_template('%s.html' %path)



if __name__ == '__main__':
    app.run()